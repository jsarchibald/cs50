import csv
import math
import sys

def final_velocity(a, d, vi):
    """"Calculates the final velocity of an object based on
        acceleration, displacement, and initial velocity"""
    
    return 0


def time(d, vi, vf):
    """Calculates the time an object takes to go a distance
       given displacement, initial velocity, and final velocity"""
    
    return 0


def s_to_m(smoots):
    """Converts Smoots to meters"""
    
    return 0


def import_data(filename):
    """Imports CSV data from filename and returns a list of rows"""
    
    return list()
    
        
def export_data(data, filename):
    """Exports CSV data to filename"""
    
    return False


def clean_data(data):
    """Takes a list of rows, and chooses the most recent one to include in the list returned"""
    
    return list()


def print_winner(stats):
    """Takes in statistics about each runner's race and prints the name of the winner"""
    
    return None
