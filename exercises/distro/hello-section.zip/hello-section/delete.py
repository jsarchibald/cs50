# Import the delete function from lib.py
from lib import delete


if __name__ == "__main__":
    # TODO: create an empty dictionary

    # TODO: add a key, id, to the dictionary, with the ID of the submission to be deleted as determined by user input

    # TODO: call delete with the dictionary as an argument

    # TODO: check that delete didn't cause an error
