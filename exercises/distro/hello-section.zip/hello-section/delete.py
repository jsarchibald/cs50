# Import the delete function from lib.py
from lib import delete

# TODO: import get_int


if __name__ == "__main__":
    # TODO: get ID to delete from user

    # TODO: call delete with the ID as an argument

    # TODO: check that delete didn't cause an error

    # TODO: remove the following line
    raise NotImplementedError("This code isn't done yet!")
