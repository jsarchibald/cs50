# Import the submit function from lib.py
from lib import submit


if __name__ == "__main__":
    # TODO: create an empty dictionary

    # TODO: fill in dictionary with keys {name, year, feeling, url, script} using user input

    # TODO: call submit, passing the dictionary as an argument

    # TODO: check for errors from submit


    raise NotImplementedError("This code isn't done yet!")
