AIRPORTS = {
    "BOS": "Boston",
    "YYC": "Calgary",
    "YEG": "Edmonton",
    "YQX": "Gander",
    "YQM": "Moncton",
    "YHZ": "Halifax",
    "YHM": "Hamilton",
    "YXU": "London, Ontario",
    "YUL": "Montreal",
    "YOW": "Ottawa",
    "YQB": "Quebec City",
    "YQR": "Regina",
    "YYZ": "Toronto",
    "YVR": "Vancouver",
    "YWG": "Winnipeg"
}

DEFAULT_STATUS = "on time"
